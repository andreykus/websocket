var springPortfolio = angular
    .module('springPortfolio', ['springPortfolio.controllers', 'springPortfolio.services']);